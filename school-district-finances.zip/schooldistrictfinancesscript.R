#install.packages('educationdata')
library(educationdata)
library(tidyverse)
??educationdata
#API test
df = get_education_data(level = 'schools',
                  source = 'ccd',
                   topic = 'directory',
                   filters = list(year = 2008),
                   add_labels = TRUE)

#generate data frames for finance data for each year

df1991 = get_education_data(level = 'school-districts',
                        source = 'ccd',
                        topic = 'finance',
                        filters = list(year = 1991),
                        add_labels = TRUE)

#no data in the API for the years 1992 and 1993 for school districts

df1994 = get_education_data(level = 'school-districts',
                        source = 'ccd',
                        topic = 'finance',
                        filters = list(year = 1994),
                        add_labels = TRUE)
df1995 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 1995),
                            add_labels = TRUE)
df1996 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 1996),
                            add_labels = TRUE)
df1997 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 1997),
                            add_labels = TRUE)
df1998 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 1998),
                            add_labels = TRUE)
df1999 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 1999),
                            add_labels = TRUE)
df2000 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2000),
                            add_labels = TRUE)
df2001 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2001),
                            add_labels = TRUE)
df2002 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2002),
                            add_labels = TRUE)
df2003 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2003),
                            add_labels = TRUE)
df2004 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2004),
                            add_labels = TRUE)
df2005 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2005),
                            add_labels = TRUE)
df2006 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2006),
                            add_labels = TRUE)
df2007 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2007),
                            add_labels = TRUE)
df2008 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2008),
                            add_labels = TRUE)
df2009 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2009),
                            add_labels = TRUE)
df2010 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2010),
                            add_labels = TRUE)
df2011 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2011),
                            add_labels = TRUE)
df2012 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2012),
                            add_labels = TRUE)
df2013 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2013),
                            add_labels = TRUE)
df2014 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2014),
                            add_labels = TRUE)
df2015 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2015),
                            add_labels = TRUE)
df2016 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2016),
                            add_labels = TRUE)
df2017 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2017),
                            add_labels = TRUE)
df2018 = get_education_data(level = 'school-districts',
                            source = 'ccd',
                            topic = 'finance',
                            filters = list(year = 2018),
                            add_labels = TRUE)

#bind the finance datasets together
masterdf = rbind(df1991, df1994, df1995, df1996, df1997, df1998, df1999, df2000, df2001, df2002, df2003, df2004, df2005,
                 df2006, df2007, df2008, df2009, df2010, df2011, df2012, df2013, df2014, df2015, df2016, df2017, df2018)
summary(masterdf)

#generate data for directory information

dir1991 = get_education_data(level = 'schools',
                        source = 'ccd',
                        topic = 'directory',
                        filters = list(year = 1991),
                        add_labels = TRUE)

dir1994 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 1994),
                             add_labels = TRUE)

dir1995 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 1995),
                             add_labels = TRUE)

dir1996 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 1996),
                             add_labels = TRUE)

dir1997 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 1997),
                             add_labels = TRUE)

dir1998 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 1998),
                             add_labels = TRUE)

dir1999 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 1999),
                             add_labels = TRUE)

dir2000 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2000),
                             add_labels = TRUE)

dir2001 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2001),
                             add_labels = TRUE)

dir2002 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2002),
                             add_labels = TRUE)

dir2003 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2003),
                             add_labels = TRUE)

dir2004 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2004),
                             add_labels = TRUE)

dir2005 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2005),
                             add_labels = TRUE)

dir2006 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2006),
                             add_labels = TRUE)

dir2007 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2007),
                             add_labels = TRUE)

dir2008 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2008),
                             add_labels = TRUE)

dir2009 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2009),
                             add_labels = TRUE)

dir2010 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2010),
                             add_labels = TRUE)

dir2011 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2011),
                             add_labels = TRUE)

dir2012 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2012),
                             add_labels = TRUE)

dir2013 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2013),
                             add_labels = TRUE)

dir2014 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2014),
                             add_labels = TRUE)

dir2015 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2015),
                             add_labels = TRUE)

dir2016 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2016),
                             add_labels = TRUE)

dir2017 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2017),
                             add_labels = TRUE)

dir2018 = get_education_data(level = 'schools',
                             source = 'ccd',
                             topic = 'directory',
                             filters = list(year = 2018),
                             add_labels = TRUE)

#creates a master dataset for the directory information
masterdir = rbind(dir1991, dir1994, dir1995, dir1996, dir1997, dir1998, dir1999, dir2000, dir2001, dir2002, dir2003, 
                  dir2004, dir2005, dir2006, dir2007, dir2008, dir2009, dir2010, dir2011, dir2012, dir2013, dir2014, 
                  dir2015, dir2016, dir2017, dir2018)

#join the two datasets together
masterdat = left_join(masterdir, masterdf)
summary(masterdat$high_cedp)

#filters out all observations which do not contain the necessary information
masterdat2 = masterdat|>
  filter(high_cedp == "Yes",
         is.na(teachers_fte) == FALSE,
         enrollment > 0,
         is.na(enrollment) == FALSE,
         is.na(exp_total) == FALSE,
         is.na(salaries_total) == FALSE)

#drops irrelevant variables
masterdat2 = masterdat2|>
  select(-c(state_mailing,
            street_mailing,
            street_location,
            city_location,
            zip_location,
            zip_mailing,
            latitude,
            longitude,
            state_location,
            state_leg_district_lower,
            state_leg_district_upper,
            congress_district_id
            ))
  
  
#exports the dataset in both .csv and .rda formats
write.table(masterdat2, file = "schooldistrictfinances.csv")
save(masterdat2, file = "schooldistrictfinances.Rda")
